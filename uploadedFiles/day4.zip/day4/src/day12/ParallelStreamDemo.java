package day12;

public class ParallelStreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
