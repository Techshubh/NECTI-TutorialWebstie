package day12;

public class TestThread {

	public static void main(String[] args) {
		PrintDemo pd=new PrintDemo();
		ThreadDemo t1=new ThreadDemo("Thread-1",pd);
		ThreadDemo t2=new ThreadDemo("Thread-2",pd);
		ThreadDemo t3=new ThreadDemo("Thread-3",pd);
		ThreadDemo t4=new ThreadDemo("Thread-4",pd);
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
