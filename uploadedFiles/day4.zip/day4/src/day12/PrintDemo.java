package day12;
import java.util.*;
import java.util.concurrent.locks.*;
public class PrintDemo {
	private final Lock queueLock=new ReenterantLock();
	public void print=
	
}
