package day14;

public class JavaExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
