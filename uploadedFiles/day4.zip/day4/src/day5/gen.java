package day5;
import java.util.*;
public class gen {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("Sachin");
		al.add("rahul");
		//al.add(10);
		String s1=(String)al.get(0);
		String s2=(String)al.get(1);
		//String s3=(String)al.get(2);

	}

}
