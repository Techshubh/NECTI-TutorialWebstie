package day13;
import java.sql.*;
public class InsertPrepared {

	public static void main(String[] args) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			PreparedStatement stmt=con.prepareStatement("insert into emptb(id,name) values(?,?)");
			stmt.setInt(1, 101);
			stmt.setString(2, "Xyz");
			//stmt.setInt(3, 2000);
			int i=stmt.executeUpdate();
			System.out.println(i+"records inserted");
			con.close();
		}
		catch(Exception e){
			System.out.println(e);
		}

	}

}
