package day13;

import java.sql.*;

public class Proc {

	public static void main(String[] args)throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
		CallableStatement stmt=con.prepareCall("{call insertR(?,?,?)}");
		stmt.setInt(1, 1011);
		stmt.setString(2,"Emp12");
		stmt.setInt(3, 78748);
		stmt.execute();
		System.out.println("success");
	}

}
