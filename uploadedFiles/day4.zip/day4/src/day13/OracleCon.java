package day13;


import java.sql.*;

public class OracleCon {

	public static void main(String[] args)throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
		Statement stmt=con.createStatement();
		stmt.executeUpdate("insert into EmpTb values(33,'emp5',5000)");
		int result=stmt.executeUpdate("update EmpTb set name='Emp33',salary=7000 where id=33");
		//int result=stmt.executeUpdate("delete from EmpTb where id=33");
		System.out.println(result+"records affected");
		//System.out.println("records affected");
		con.close();
		
	}

}
