package day13;

import java.util.Arrays;
import java.util.List;

public class ReducingWithstreams {
	static List<Employee> employeeList=Arrays.asList(new Employee("Tom", 45, 7000.0),
			new Employee("harry", 26, 5000.0),
			new Employee("Ethan", 28, 8000.0),
			new Employee("Nancy", 45, 12000.0),
			new Employee("Deborah", 35, 9000.0));
	public static void main(String[] args) {
		Double totalSalaryExpense=employeeList.stream().map(emp->emp.getSalary()).reduce(0.00,(a,b)->a+b);
		Optional<Employee> maxSalaryEmp=employeeList.stream().reduce((a,b)->a>b?a:b);
		System.out.println("Total salary expense:"+totalSalaryExpense);

	}

}
