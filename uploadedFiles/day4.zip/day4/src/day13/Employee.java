package day13;
import java.util.*;
public class Employee {
	private String name;
	private Integer age;
	private Double salary;
	public Employee(String name, Integer age, Double salary)
	{
		this.name=name;
		this.age=age;
		this.salary=salary;
	}
	public Double getSalary(){
		return this.salary;
	}
	public String toString(){
		return "Employee name:"+this.name+"age:"+this.age+"Salary:"+this.salary;
	}
}
