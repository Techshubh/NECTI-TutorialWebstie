package day11;
import java.util.*;
public class Task2 {

	public static void main(String[] args) {
		TimerTask task= new TimerTask()
		{
			@Override 
			public void run(){
				System.out.println("Hello!!");
			}
		};
		Timer timer= new Timer();
		long delay=0;
		long intervalPeriod=1*1000;
		timer.scheduleAtFixedRate(task, delay, intervalPeriod);
	}

}
