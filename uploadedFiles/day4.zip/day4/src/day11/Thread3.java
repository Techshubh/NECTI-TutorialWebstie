package day11;

class MineThread implements Runnable
{
	Account account;
	public MineThread(Account s){ account =s ;}
	public void run(){account.deposit();}
	}
class YourThread implements Runnable
{
	Account account;
	public YourThread(Account s){ account =s ;}
	public void run(){account.withdraw();}
	}
class HerThread implements Runnable
{
	Account account;
	public HerThread(Account s){ account =s ;}
	public void run(){account.enquire();}
	}
public class Thread3 {
	
}
