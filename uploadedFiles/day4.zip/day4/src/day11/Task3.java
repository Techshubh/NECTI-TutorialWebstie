package day11;
import java.util.concurrent.*;
public class Task3 {
	public static void main(String[] args) {
		Runnable runnable= new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("Hello");
			}
		};
		ScheduledExecutorService service=Executors.newSingleThreadScheduledExecutor();
		service.scheduleAtFixedRate(runnable, 0, 1, TimeUnit.SECONDS);
	}
}
