package day11;
import java.util.*;
public class ScheduledTask extends TimerTask{
	Date now;
	public void run(){
		now=new Date();
		System.out.println("Time is:"+now);
	}

}
