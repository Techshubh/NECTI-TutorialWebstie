package day11;
import java.util.*;
public class SchedulerMain {

	public static void main(String[] args)throws InterruptedException {
		Timer time=new Timer();
		ScheduledTask st= new ScheduledTask();
		time.schedule(st, 0,1000);
		for(int i=0;i<=5;i++)
		{
			System.out.println("Execution in main thread.."+i);
			Thread.sleep(2000);
			if(i==5){
				System.out.println("App term");
				System.exit(0);
			}
		}
	}

}
