package day11;

public class IBS {

	public static void main(String[] args) {
		Account obj=new Account();
		Thread t1=new Thread(new MineThread(obj));
		Thread t2=new Thread(new YourThread(obj));
		Thread t3=new Thread(new HerThread(obj));
		t1.start();t2.start();t3.start();
	}

}
