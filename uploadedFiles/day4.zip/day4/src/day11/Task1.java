package day11;

public class Task1 {

	public static void main(String[] args) {
		final long timeinterval=1000;
		Runnable runnable=new Runnable() {
			
			@Override
			public void run() {
				while(true){
					System.out.println("hello!!");
					try{
						Thread.sleep(timeinterval);
					}
					catch(InterruptedException e)
					{
						e.printStackTrace();
					}
				}
				
			}
		};
		Thread thread = new Thread(runnable);
		thread.start();

	}

}
