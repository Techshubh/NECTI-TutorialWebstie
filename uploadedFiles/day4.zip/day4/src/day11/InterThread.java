package day11;
class MyThreads implements Runnable{
	public void run(){
		System.out.println("this thread is running");
	}
}
public class InterThread {

	public static void main(String[] args) {
		Thread t1=new Thread(new MyThreads());
		t1.start();
		
		

	}

}
