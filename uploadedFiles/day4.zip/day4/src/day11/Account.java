package day11;

public class Account {
int balance;
public synchronized void deposit() {
	balance+=10;
	
}
public synchronized void withdraw()
{
	balance-=5;
}
public synchronized void enquire(){
	System.out.println(balance);
}
	

}
