package day11;

public class Task4 {

	public static void main(String[] args) {
//		Runnable r=()->System.out.println("Running");
//		Thread t=new Thread(r);
//		thread.start();

	}

}
