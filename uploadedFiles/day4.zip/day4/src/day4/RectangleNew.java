package day4;

public class RectangleNew implements Shape {
	@Override
	public void draw()
	{
		System.out.println("Inside Rect draw");
	}
	

}
