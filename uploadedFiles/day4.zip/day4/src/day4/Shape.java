package day4;

public interface Shape {
	void draw();
}
