package day4;

public class Green implements Color {
	@Override
	public void fill(){
		System.out.println("Inside green fill");
	}

}
