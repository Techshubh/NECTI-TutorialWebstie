package day4;

public class CircleNew implements Shape {
	@Override
	public void draw()
	{
		System.out.println("Inside circle draw");
	}
	

}
