package day4;

public interface Color
{
	void fill();
}
