package day9;
import java.io.*;
public class Demoser implements java.io.Serializable{
	public int a;
	public String b;
	public Demoser(int a, String b)
	{
		this.a=a;
		this.b=b;
	}
}
