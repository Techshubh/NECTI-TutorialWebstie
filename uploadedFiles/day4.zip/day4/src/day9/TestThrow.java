package day9;

public class TestThrow {

	void validate(int age){
		if(age<18)
			throw new ArithmeticException("not valid");
		else
			System.out.println("welcome");
	}
	public static void main(String[] args) {
		
		(new TestThrow()).validate(13);
		System.out.println("rest of code");

	}

}
