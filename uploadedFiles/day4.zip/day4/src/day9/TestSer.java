package day9;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestSer {

	public static void main(String[] args) {
		Demoser ob=new Demoser(1, "helloWorld");
		String filename="file.ser";
		try{
			FileOutputStream file= new FileOutputStream(filename);
			ObjectOutputStream out= new ObjectOutputStream(file);
			//Method for serialization
			out.writeObject(ob);
			out.close();
			file.close();
			System.out.print("Object has been serialized");
		}
		catch(IOException ex)
			{System.out.print("IOException is caught");}
		
		Demoser obj1=null;
		try{//Deserialization
			//reading the object from a file
			FileInputStream file= new FileInputStream(filename);
			ObjectInputStream in= new ObjectInputStream(file);
			obj1=(Demoser)in.readObject();
			in.close();
			file.close();
			System.out.println("Object has been deserialized");
			System.out.println("a="+obj1.a);
			System.out.println("b="+obj1.b);
		}
		catch(IOException e)
			{System.out.print("io caught");}
		catch(ClassNotFoundException e2)
		{System.out.print("class not found");}
		
	}

}
