package day9;

public class TestMultiple {

	public static void main(String[] args) {
		
			int a[]=new int[5];
			a[5]=30/0;
		

		System.out.println("rest of code");
	}

}
