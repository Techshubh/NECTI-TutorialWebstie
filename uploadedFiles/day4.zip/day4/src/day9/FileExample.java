package day9;
import java.io.*;


public class FileExample {
public static final String FILE_PATH="test.txt";
	public static void main(String[] args)throws IOException {
		createFile();
		writeFile();
		countFile();
		copyFile();
		deleteFile();

	}
	public static void createFile()throws IOException
	{
		File file=new File(FILE_PATH);
		boolean newFile=file.createNewFile();
		if(newFile)
		{
			System.out.println("create new file");
		}
		else
		{
			System.out.println("exits");
		}
		
		boolean mkdirs = file.mkdir();
		if(mkdirs)
			System.out.println("create mkdirs");
		else
			System.out.println("Exists dir");
		
		System.out.println("file name:" + file.getName());
		System.out.println("file path:" + file.getParent());
	}
	public static void writeFile()throws IOException
	{
		File file=new File(FILE_PATH);
		OutputStream outputStream = new FileOutputStream(file);
		byte[] bytes = {1, 2, 3, 4};
		outputStream.write(bytes);
		outputStream.close();
	}
	public static void deleteFile() {
		File file=new File(FILE_PATH+"_cp");
		if(file.delete()){
			System.out.println("Delete file");
		}
	}
	public static void countFile()throws IOException
	{
		int count =0;
		File file= new File(FILE_PATH);
		InputStream inputStream = new FileInputStream(file);
		while(inputStream.read()!=-1)
			count++;
		System.out.println(file.getName()+" length :"+count);
		inputStream.close();
	}
	public static void copyFile()throws IOException
	{
		byte[] buffer=new byte[512];
		File file= new File(FILE_PATH);
		InputStream inputStream= new FileInputStream(file);
		File outFile= new File(FILE_PATH+"_cp");
		FileOutputStream os = new FileOutputStream(outFile);
		while(inputStream.read(buffer)!=-1)
		{
			os.write(buffer);
		}
		System.out.println("copy"+file.getPath()+"to"+outFile.getPath());
		inputStream.close();
		os.close();
	}

}
