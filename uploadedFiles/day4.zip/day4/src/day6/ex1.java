package day6;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;;

public class ex1 {

	public static void main(String[] args) {
		ex1 obj=new ex1();
		obj=new ex1();
	}

}
