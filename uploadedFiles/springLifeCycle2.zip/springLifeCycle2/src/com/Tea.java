package com;

public class Tea implements HotDrink{
	public Tea() {
		System.out.println("Tea is called");
	}
	@Override
	public void prepareHotDrink()
	{
		System.out.println("Dear customer we are preparing tea for you");
	}

}
