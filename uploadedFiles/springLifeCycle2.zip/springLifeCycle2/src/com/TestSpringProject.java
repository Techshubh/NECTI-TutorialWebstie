/**
 * 
 */
package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author admin1
 *
 */
public class TestSpringProject {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("Bean.xml");
		((AbstractApplicationContext)context).registerShutdownHook();
		Restaurant restaurant1=(Restaurant) context.getBean("restaurantBean");
		restaurant1.setwelcomeNote("welcome1");
		restaurant1.greetCustomer();
		Restaurant restaurant=(Restaurant) context.getBean("restaurantBean");
		restaurant.greetCustomer();
	}

}
