package com;

public interface HotDrink {
public void prepareHotDrink();
}
