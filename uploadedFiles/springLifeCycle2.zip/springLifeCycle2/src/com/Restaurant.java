package com;

public class Restaurant {
	private String welcomeNote;
	public void setwelcomeNote(String wn)
	{
		this.welcomeNote=wn;
	}
public void greetCustomer() {
	System.out.println(welcomeNote);
}
public void init() {
	System.out.println("Restaurant bean is going through init");
}
public void destroy() {
	System.out.println("Bean will destroy now");
}
}
