package hibernate;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Main {
	public static void main(String[] args) {
		
	
		// TODO Auto-generated constructor stub
		Student student=new Student();
		student.setStudent_name("AA4");
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(student);
		student=(Student)session.get(Student.class, 1);
		System.out.println("STu Obj st name is" +student.getStudent_name());
		student.setStudent_name("aa4 modified");
		session.getTransaction().commit();
		session.close();
		
	}

}
