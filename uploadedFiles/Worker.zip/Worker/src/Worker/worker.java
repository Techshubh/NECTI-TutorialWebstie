package day2;

public abstract class worker {
	String name;
	abstract int pay();
	abstract void display();
}
