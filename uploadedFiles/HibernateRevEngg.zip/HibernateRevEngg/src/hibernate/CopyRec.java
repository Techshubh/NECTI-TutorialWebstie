package hibernate;

import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class CopyRec {
public static void main(String[] args) {
	SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
	Session session=sessionFactory.openSession();
	session.beginTransaction();
	Query qry=session.createQuery("from Employee");
	List<EmployeeId> list=((org.hibernate.query.Query)qry).list();
	Iterator<EmployeeId> iterator = list.iterator();
	while (iterator.hasNext()) {
		EmployeeId e=iterator.next();
		int n=e.getEmployeeId();
		if(isPrime(n))
		{
			System.out.print(n+" ");
			System.out.println(e.getEname());
		}
	}
	session.close();
}
static boolean isPrime(int n) 
{ 
    // Corner case 
    if (n <= 1) return false; 
  
    // Check from 2 to n-1 
    for (int i = 2; i < n; i++) 
        if (n % i == 0) 
            return false; 
  
    return true; 
} 
}
