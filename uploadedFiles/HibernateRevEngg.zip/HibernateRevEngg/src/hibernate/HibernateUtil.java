package hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {
final static StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure().build();
private static SessionFactory  sFactory=null;
private static SessionFactory buildSessionFactory() {
	try {
		sFactory=new MetadataSources(registry).buildMetadata().buildSessionFactory();
		return sFactory;
	}catch (Exception e) {
		// TODO: handle exception
		StandardServiceRegistryBuilder.destroy(registry);
		throw new ExceptionInInitializerError(e);
	}
}
public static SessionFactory getSessionFactory() {
	if(sFactory==null)
		buildSessionFactory();
	return sFactory;
}

}
